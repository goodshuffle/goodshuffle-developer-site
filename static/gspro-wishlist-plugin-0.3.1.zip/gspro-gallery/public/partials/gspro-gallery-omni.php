<?php

/**
 * Provide elements to be embedded on all pages.
 *
 * @link       http://github.com/goodshuffle/gspro-gallery
 * @since      0.1.0
 *
 * @package    Gspro_Gallery
 * @subpackage Gspro_Gallery/public/partials
 */
?>

<div class="gspro-gallery-omni-present">
  <script src="https://unpkg.com/tua-body-scroll-lock@1.0.0"></script>
  <?php
    $gspro_wishlist_active = get_option('gspro_wishlist_active', false);
    $gspro_gallery_page = get_option('gspro_gallery_page_name', false);
    $in_gallery = is_page($gspro_gallery_page);
    if ( $gspro_wishlist_active || $in_gallery ) { ?>
      <gspro-wishlist route="/wishlist"></gspro-wishlist>
  <?php } ?>
  <gspro-item-detail data-mode="inactive"
                     class="gspro-u-fullscreen"
                     route="/item/:id/:title*"></gspro-item-detail>
  <gspro-sprite></gspro-sprite>
</div>
