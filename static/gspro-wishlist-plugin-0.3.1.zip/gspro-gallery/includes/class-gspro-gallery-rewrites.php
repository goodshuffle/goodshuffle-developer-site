<?php

/**
 * Register rewrite rules for the item details page
 *
 * @link       http://github.com/goodshuffle/gspro-gallery
 * @since      0.1.0
 *
 * @package    Gspro_Gallery
 * @subpackage Gspro_Gallery/includes
 */

/**
 * Register the rewrites provided by this plugin.
 *
 * @package    Gspro_Gallery
 * @subpackage Gspro_Gallery/includes
 * @author     Jon Morton <jon@goodshuffle.com>
 */

class Gspro_Gallery_Rewrites
{

  public static function activate() {
    flush_rewrite_rules();
  } 

  public static function deactivate() {
    flush_rewrite_rules();
  }

  public function __construct()
  {
    // add_action('init', array($this, 'gspro_item_detail_rules'));
    // add_filter('query_vars', array($this, 'gspro_item_detail_query'));
  }

}
