(function($) {
  "use strict";
})(jQuery);
