<?php

/**
 * Provide admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       http://github.com/goodshuffle/gspro-gallery
 * @since      0.1.0
 *
 * @package    Gspro_Gallery
 * @subpackage Gspro_Gallery/admin/partials
 */
?>

<?php
   error_reporting(E_ALL);
   ini_set('display_errors', true);
?>

<div class="gs-admin">
  <div class="gs-admin-header">
    <div class="gs-admin-pull-left">
      <img src="<?php echo esc_url(plugins_url('../img/brand@3x.png', __FILE__)); ?>" alt="gspro" width="239" />
    </div>
    <div class="gs-admin-pull-right">
      <a href="http://help.goodshuffle.com/en/articles/3517420-how-can-i-connect-my-goodshuffle-pro-account-with-my-wordpress-site" target="_blank" rel="noopener" class="button gs-admin-help">Help</a>
    </div>
  </div>

  <div>
    <h2>Connect your Account</h2>
    <?php
      if (isset($_REQUEST['gspro_settings_form'])) {
        $company = sanitize_text_field($_POST['gspro_company_key']);
        update_option('gspro_company_key', $company);

        $gspro_gallery_page_name = sanitize_text_field($_POST['gspro_gallery_page_name']);
        update_option('gspro_gallery_page_name', $gspro_gallery_page_name);

        $gspro_default_category = sanitize_text_field($_POST['gspro_default_category']);
        update_option('gspro_default_category', $gspro_default_category);

        $gspro_default_group = sanitize_text_field($_POST['gspro_default_group']);
        update_option('gspro_default_group', $gspro_default_group);

        $gspro_default_tags = sanitize_text_field($_POST['gspro_default_tags']);
        update_option('gspro_default_tags', $gspro_default_tags);

        $gspro_default_search = sanitize_text_field($_POST['gspro_default_search']);
        update_option('gspro_default_search', $gspro_default_search);

        $gspro_default_item_list_size = sanitize_text_field($_POST['gspro_default_item_list_size']);
        update_option('gspro_default_item_list_size', $gspro_default_item_list_size);

        if (isset($_POST['gspro_wishlist_active'])) {
          update_option('gspro_wishlist_active', true);
          $gspro_wishlist_active = true;
        } else {
          delete_option('gspro_wishlist_active');
          $gspro_wishlist_active = false;
        }
        ?>
      <div>
        <p><strong>Settings updated.</strong></p>
      </div>
      <?php
      } else {
        $company = get_option('gspro_company_key');
        $gspro_wishlist_active = get_option('gspro_wishlist_active', false);
        $gspro_gallery_page_name = get_option('gspro_gallery_page_name', 'goodshuffle');
        $gspro_default_category = get_option('gspro_default_category', '');
        $gspro_default_group = get_option('gspro_default_group', '');
        $gspro_default_search = get_option('gspro_default_search', '');
        $gspro_default_tags = get_option('gspro_default_tags', '');
        $gspro_default_item_list_size = get_option('gspro_default_item_list_size','20');
      }
    ?>
    <p class="gs-admin-subtitle">
      Need one? <a href="https://pro.goodshuffle.com/signup" target="_blank" rel="noopener">Sign-up!</a>.
    </p>
    <hr />
    <form name="gspro_form" method="post" action="<?= $_SERVER['REQUEST_URI'] ?>">
      <input type="hidden" name="gspro_settings_form" value="yes">
      <table class="form-table">
        <tbody>
          <tr>
            <th scope="row">
              <label for="gspro_company_key">Public Browser Key</label>
            </th>
            <td>
              <input type="text" name="gspro_company_key" value="<?= $company ?>" size="20" class="regular-text">
            </td>
          </tr>
          <tr>
            <th scope="row">
              <label for="gspro_company_key">Display Inventory on Page</label>
            </th>
            <td>
              <input type="text" name="gspro_gallery_page_name" value="<?= $gspro_gallery_page_name ?>" size="20" class="regular-text">
              <p class="description">The page slug where your inventory will be displayed.</p>
            </td>
          </tr>
          <tr>
            <th scope="row">
              <label for="gspro_company_key">Default Category</label>
            </th>
            <td>
              <input type="text" name="gspro_default_category" value="<?= $gspro_default_category ?>" size="20" class="regular-text">
            </td>
          </tr>
          <tr>
            <th scope="row">
              <label for="gspro_company_key">Default Group</label>
            </th>
            <td>
              <input type="text" name="gspro_default_group" value="<?= $gspro_default_group ?>" size="20" class="regular-text">
            </td>
          </tr>
          <tr>
            <th scope="row">
              <label for="gspro_company_key">Default Search</label>
            </th>
            <td>
              <input type="text" name="gspro_default_search" value="<?= $gspro_default_search ?>" size="20" class="regular-text">
              <p class="description">Use keyword search to select initially displayed items?</p>
            </td>
          </tr>
          <tr>
            <th scope="row">
              <label for="gspro_company_key">Default Tags</label>
            </th>
            <td>
              <input type="text" name="gspro_default_tags" value="<?= $gspro_default_tags ?>" size="20" class="regular-text">
              <p class="description">Use tags to select initially displayed items?</p>
            </td>
          </tr>
          <tr>
            <th scope="row">
              <label for="gspro_company_key">Default # of Items Listed</label>
            </th>
            <td>
              <input type="text" name="gspro_default_item_list_size" value="<?= $gspro_default_item_list_size ?>" size="20" class="regular-text">
            </td>
          </tr>
          <tr>
            <th scope="row">
              <label for="gspro_wishlist_active">Wishlist</label>
            </th>
            <td>
              <label>
                <input type="checkbox" id="gspro_wishlist_active" name="gspro_wishlist_active" value="true" <?= $gspro_wishlist_active ? "checked" : "" ?>>
                Display wishlist on all pages.
              </label>
            </td>
          </tr>
        </tbody>
      </table>
      <div class="submit">
        <input type="submit" name="Submit" value="<?php _e('Update Options', 'gspro_trdom') ?>" class="button button-primary" />
      </div>
    </form>
  </div>

<?php

# TBD: Provide a built-in library?
# $gspro_modern_js_default = '/wp-content/plugins/gspro-gallery/public/js/dist/gspro-wc/gspro-wc.esm.js';
# $gspro_legacy_js_default = '/wp-content/plugins/gspro-gallery/public/js/dist/gspro-wc/gspro-wc.js';

$gspro_modern_js_default = 'https://unpkg.com/@goodshuffle/gspro-wc@0.3.1/dist/gspro-wc/gspro-wc.esm.js';
$gspro_legacy_js_default = 'https://unpkg.com/@goodshuffle/gspro-wc@0.3.1/dist/gspro-wc/gspro-wc.js';

if (isset($_GET['advanced'])) {
?>
  <div>
    <h2>Advanced Settings</h2>
    <?php
      if (isset($_REQUEST['gspro_developer_form'])) {
    ?>
    <div><strong>Advanced options saved.</strong></div>
    <?php
        if (empty($_POST['gspro_legacy_js_url'])) {
          delete_option('gspro_legacy_js_url');
        } else {
          $gspro_legacy_js_url = sanitize_text_field($_POST['gspro_legacy_js_url']);
          update_option('gspro_legacy_js_url', $gspro_legacy_js_url);
        }
        if (empty($_POST['gspro_modern_js_url'])) {
          delete_option('gspro_modern_js_url');
        } else {
          $gspro_modern_js_url = sanitize_text_field($_POST['gspro_modern_js_url']);
          update_option('gspro_modern_js_url', $gspro_modern_js_url);
        }
        $gspro_data_url = sanitize_text_field($_POST['gspro_data_url']);
        if (empty($gspro_data_url)) {
          delete_option('gspro_data_url');
        } else {
          update_option('gspro_data_url', $gspro_data_url);
        }
        $gspro_icon_url = sanitize_text_field($_POST['gspro_icon_url']);
        if (empty($gspro_icon_url)) {
          delete_option('gspro_icon_url');
        } else {
          update_option('gspro_icon_url', $gspro_icon_url);
        }
      }
      $gspro_modern_js_url = get_option('gspro_modern_js_url', $gspro_modern_js_default);
      $gspro_legacy_js_url = get_option('gspro_legacy_js_url', $gspro_legacy_js_default);
      $gspro_data_url = get_option('gspro_data_url', 'https://data.goodshuffle.com/vendor');
      $gspro_icon_url = get_option('gspro_icon_url', plugins_url('/gspro-gallery/public/img/icons.svg'));
    ?>
    <p class="gs-admin-subtitle">
      Changing these settings without a full understanding of what they do may
      cause serious problems with your site.
    </p>
    <hr />
    <form name="gspro_developer_form" method="post" action="<?= $_SERVER['REQUEST_URI'] ?>">
      <input type="hidden" name="gspro_developer_form" value="yes">
      <table class="form-table">
        <tbody>
          <tr>
            <th scope="row">
              <label for="gspro_data_url">Data Source</label>
            </th>
            <td>
              <input type="text" name="gspro_data_url" value="<?= $gspro_data_url ?>" size="20" class="regular-text">
            </td>
          </tr>
          <tr>
            <th scope="row">
              <label for="gspro_icon_url">Icon URL</label>
            </th>
            <td>
              <input type="text" name="gspro_icon_url" value="<?= $gspro_icon_url ?>" size="20" class="regular-text">
            </td>
          </tr>
          <tr>
            <th scope="row">
              <label for="gspro_modern_js_url">Modern JS</label>
            </th>
            <td>
              <input type="text" name="gspro_modern_js_url" value="<?= $gspro_modern_js_url ?>" size="20" class="regular-text">
            </td>
          </tr>
          <tr>
            <th scope="row">
              <label for="gspro_legacy_js_url">Legacy JS</label>
            </th>
            <td>
              <input type="text" name="gspro_legacy_js_url" value="<?= $gspro_legacy_js_url ?>" size="20" class="regular-text">
            </td>
          </tr>
        </tbody>
      </table>
      <div class="submit">
        <input type="submit" name="Submit" value="<?php _e('Save Advanced Options', 'gspro_trdom') ?>" class="button button-primary" />
      </div>
    </form>
  </div>
<?php } ?>

</div>