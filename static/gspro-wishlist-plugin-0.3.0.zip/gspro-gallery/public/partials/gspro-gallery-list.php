<?php

/**
 * Provide elements to be embedded on the designated gallery page.
 *
 * @link       http://github.com/goodshuffle/gspro-gallery
 * @since      0.1.0
 *
 * @package    Gspro_Gallery
 * @subpackage Gspro_Gallery/public/partials
 */
?>

<gspro-item-gallery size="25" id="gspro-gallery"
  category="<?= get_option('gspro_default_category','') ?>"
  group="<?= get_option('gspro_default_group','') ?>"
  search="<?= get_option('gspro_default_search','') ?>"
  tags="<?= get_option('gspro_default_tags','') ?>"
  size="<?= get_option('gspro_default_item_list_size','') ?>">
</gspro-item-gallery>
