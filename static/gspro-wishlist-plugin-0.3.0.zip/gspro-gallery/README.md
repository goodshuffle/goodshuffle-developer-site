# The Goodshuffle Wishlist Plugin

This plugin provides you with a way to embed your Goodshuffle Pro inventory on your own website.

## Building

TODO...

```
cd ..; zip -r gspro-wishlist-plugin-$(date "+%Y-%m-%d").zip gspro-gallery -x '*.git*'
```

## Contributing

## License

TODO: Probably GPLv2 (or something compatible)
